"""
pyCloudWatcher.

Native Python bindings for the LunaticoAstro's CloudWatcher weather station API.
"""

__version__ = "0.1.0"
__author__ = 'Stephen Hudson'
__credits__ = 'Argonne National Laboratory'
